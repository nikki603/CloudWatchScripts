#!/bin/bash

echo "Installing PERL";
sudo apt-get install libwww-perl libdatetime-perl
